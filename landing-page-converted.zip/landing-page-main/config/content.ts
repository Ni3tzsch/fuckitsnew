export const siteConfig = {
  companyName: "DJASSApp",
  tagline: "L'entrepreneuriat à portée de voix",
  contact: {
    email: "akwaba@djassapp.com",
    listAnchor: "#liste",
  },
  socials: {
    facebook: "https://www.facebook.com/profile.php?id=61590465520390",
    linkedin: "https://www.linkedin.com/company/djassapp/",
    instagram: "https://www.instagram.com/djassapp/",
  },
};
