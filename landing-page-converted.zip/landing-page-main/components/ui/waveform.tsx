"use client";

import { useEffect, useState } from "react";

interface WaveformProps {
  heights: number[];
  step?: number;
}

export function Waveform({ heights, step = 0.07 }: WaveformProps) {
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mediaQuery.matches);

    const listener = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mediaQuery.addEventListener("change", listener);
    return () => mediaQuery.removeEventListener("change", listener);
  }, []);

  return (
    <>
      {heights.map((h, i) => {
        const style: React.CSSProperties = {
          "--h": `${h}px`,
          height: `${Math.max(8, Math.round(h * 0.55))}px`,
        } as React.CSSProperties;

        if (!reducedMotion) {
          style.animationDelay = `${i * step}s`;
          style.animationDuration = `${1.1 + (i % 5) * 0.12}s`;
        }

        return <span key={i} style={style} />;
      })}
    </>
  );
}
