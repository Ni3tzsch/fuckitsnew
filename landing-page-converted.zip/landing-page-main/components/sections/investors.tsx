export function Investors() {
  return (
    <section className="sec" id="investisseurs">
      <div className="wrap">
        <div className="sec-head reveal">
          <div className="eyebrow">
            <span className="tick"></span>
            <span className="mono">Investisseurs &amp; partenaires</span>
          </div>
          <h2>
            Nous construisons.{" "}
            <span className="em grad-text">Nous cherchons les bonnes mains.</span>
          </h2>
        </div>
        <div className="inv-grid">
          <div className="reveal">
            <p className="inv-intro">
              DJASSApp est en phase de pré-lancement. Nous préparons une
              première version pour les entrepreneurs, un parcours d'inscription
              vocal avec le DJASSAman, et un pilote terrain à Abidjan. Nous
              cherchons celles et ceux qui veulent construire cette
              infrastructure avec nous.
            </p>
            <ul className="inv-list">
              <li>
                <span className="ix">→</span>
                <span>
                  Investisseurs pré-seed &amp; business angels alignés sur
                  l'impact
                </span>
              </li>
              <li>
                <span className="ix">→</span>
                <span>
                  Incubateurs &amp; accélérateurs ouest-africains et
                  internationaux
                </span>
              </li>
              <li>
                <span className="ix">→</span>
                <span>Talents produit, tech (voix / IA) et growth</span>
              </li>
              <li>
                <span className="ix">→</span>
                <span>Relais terrain à Abidjan &amp; experts marketplace</span>
              </li>
              <li>
                <span className="ix">→</span>
                <span>
                  Organisations engagées dans l'inclusion numérique et
                  économique
                </span>
              </li>
            </ul>
          </div>
          <div className="inv-box reveal">
            <span className="mono">Parlons-en</span>
            <h3>Vous voulez en savoir plus, ou en être ?</h3>
            <p>
              Recevez le dossier de présentation et suivez les prochaines étapes
              du projet, du pilote à la levée.
            </p>
            <a
              href="#liste"
              className="btn btn-primary"
              style={{ display: "inline-block" }}
            >
              Demander le dossier
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
