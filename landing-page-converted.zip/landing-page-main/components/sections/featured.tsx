export function Featured() {
  return (
    <section className="featured" aria-label="Accompagné par">
      <div className="wrap featured-inner">
        <div className="featured-label">Accompagné par</div>
        <div className="featured-logos">
          <div className="featured-logo" aria-label="emlyon venture labs">
            <img
              className="logo-square"
              src="https://sites-wordpress.em-lyon.com/venturelabs/files/2024/12/cropped-venturelabs_emlyon_business_school_logo.jpeg"
              loading="lazy"
              decoding="async"
              alt="emlyon venture labs"
            />
          </div>
          <div className="featured-logo" aria-label="Station F">
            <img
              className="logo-station"
              src="https://upload.wikimedia.org/wikipedia/commons/d/db/Logo_STATION_F.svg"
              loading="lazy"
              decoding="async"
              alt="Station F"
            />
          </div>
          <div className="featured-logo" aria-label="French Tech Saint-Etienne">
            <img
              className="logo-frenchtech"
              src="https://rdv.lafrenchtech-stl.com/images/configuration/logos/65f4627322b84618522253.png"
              loading="lazy"
              decoding="async"
              alt="La French Tech Saint-Etienne Lyon"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
