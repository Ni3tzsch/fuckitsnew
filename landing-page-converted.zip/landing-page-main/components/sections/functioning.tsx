export function Functioning() {
  return (
    <section className="sec" id="fonctionnement">
      <div className="wrap">
        <div className="sec-head reveal">
          <div className="eyebrow">
            <span className="tick"></span>
            <span className="mono">Fonctionnement du DJASSAman</span>
          </div>
          <h2>
            Une conversation courte.{" "}
            <span className="em grad-text">Une boutique prête à vendre.</span>
          </h2>
          <p>
            Le DJASSAman remplace les formulaires par un échange naturel. Il
            comprend l'activité, structure les informations, lit les images
            produits et aide ensuite le marchand à gérer son business à la voix.
          </p>
        </div>

        <div className="flow-shell">
          <div className="flow-main reveal">
            <div className="flow-kicker">
              <span>01</span> Onboarding vocal "Zero Friction"
            </div>
            <h3>
              Le marchand parle comme avec une personne, le DJASSAman construit
              comme un système.
            </h3>
            <p className="flow-intro">
              L'inscription devient une discussion fluide : moins de trois
              minutes pour passer de la parole à une boutique structurée.
            </p>

            <div className="dialogues">
              <div className="dialogue">
                <p className="dialogue-line">
                  <span className="avatar">🤖</span>
                  <span>
                    <strong>DJASSAman :</strong> "Bonjour ! Bienvenue sur
                    DJASSApp. En une phrase, tu vends quoi ?"
                  </span>
                </p>
                <p className="dialogue-line merchant">
                  <span className="avatar">🧑‍💼</span>
                  <span>
                    <strong>Marchande :</strong> "Moi c'est Fatou, je vends des
                    vêtements de créateurs et des pagnes Wax."
                  </span>
                </p>
              </div>
              <div className="dialogue">
                <p className="dialogue-line">
                  <span className="avatar">🤖</span>
                  <span>
                    <strong>DJASSAman :</strong> "Magnifique Fatou. Prends en
                    photo les articles que tu veux mettre en vente."
                  </span>
                </p>
                <p className="dialogue-line merchant">
                  <span className="avatar">🧑‍💼</span>
                  <span>
                    <strong>Marchande :</strong> "[Prend 3 photos de robes avec
                    l'appareil intégré]"
                  </span>
                </p>
              </div>
              <div className="dialogue">
                <p className="dialogue-line">
                  <span className="avatar">🤖</span>
                  <span>
                    <strong>DJASSAman :</strong> "Cette robe est superbe. Quel
                    est son nom et son prix ?"
                  </span>
                </p>
                <p className="dialogue-line merchant">
                  <span className="avatar">🧑‍💼</span>
                  <span>
                    <strong>Marchande :</strong> "C'est la robe Prestige. Elle
                    est à 5 000 FCFA, mais le client peut discuter."
                  </span>
                </p>
              </div>
              <div className="dialogue">
                <p className="dialogue-line">
                  <span className="avatar">🤖</span>
                  <span>
                    <strong>DJASSAman :</strong> "C'est noté, elle est
                    enregistrée. Tu as un magasin physique ou un point de
                    retrait ?"
                  </span>
                </p>
                <p className="dialogue-line merchant">
                  <span className="avatar">🧑‍💼</span>
                  <span>
                    <strong>Marchande :</strong> "J'ai une petite boutique au
                    marché de Cocody, en face de la SGBCI."
                  </span>
                </p>
              </div>
            </div>
          </div>

          <aside className="flow-side reveal">
            <span className="mono">Ce que l'IA fait en arrière-plan</span>
            <div className="backstage">
              <div className="backstage-step">
                <h4>Création du profil</h4>
                <p>
                  Elle crée "Chez Fatou", classe la boutique en Mode / Vêtements
                  et prépare la structure commerciale.
                </p>
              </div>
              <div className="backstage-step">
                <h4>Analyse des produits</h4>
                <p>
                  La reconnaissance visuelle isole chaque vêtement, reconnaît
                  les couleurs, les motifs Wax et les éléments utiles à la
                  recherche.
                </p>
              </div>
              <div className="backstage-step">
                <h4>Fiche produit enrichie</h4>
                <p>
                  Elle crée la robe Prestige, fixe le prix affiché à 5 000 FCFA
                  et note une négociation possible jusqu'à 4 500 FCFA.
                </p>
              </div>
              <div className="backstage-step">
                <h4>Mise en ligne</h4>
                <p>
                  Elle géolocalise le point de retrait, active la boutique et
                  prépare les options de livraison partenaires.
                </p>
              </div>
            </div>
            <div className="time-chip">Moins de 3 minutes</div>
          </aside>
        </div>

        <div className="ops-band reveal">
          <div>
            <div className="flow-kicker">
              <span>02</span> Mode "Voice Ops"
            </div>
            <h3>Une fois en ligne, le marchand pilote son activité à la voix.</h3>
            <p>
              DJASSApp ne s'arrête pas à la création de boutique. Le DJASSAman
              devient l'assistant opérationnel du quotidien, sans interface
              complexe à apprendre.
            </p>
          </div>
          <div className="ops-list">
            <div className="ops-item">
              <span>Suivi de l'activité</span>
              <p>
                "DJASSAman, j'ai combien de commandes aujourd'hui ?" Il répond
                avec les commandes en attente, les produits qui marchent et les
                priorités du jour.
              </p>
            </div>
            <div className="ops-item">
              <span>Gestion financière</span>
              <p>
                "Je veux retirer 150 000 FCFA vers mon compte Wave." Il vérifie
                le solde, prépare l'opération et demande une validation
                sécurisée.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
