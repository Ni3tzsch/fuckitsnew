export function Solution() {
  return (
    <section className="sec">
      <div className="wrap">
        <div className="sec-head reveal">
          <div className="eyebrow">
            <span className="tick"></span>
            <span className="mono">La solution</span>
          </div>
          <h2>
            Trois mots suffisent :{" "}
            <span className="em grad-text">parlez, publiez, vendez.</span>
          </h2>
          <p>
            Le DJASSAman est le copilote vocal de DJASSApp. Il guide
            l'entrepreneur par la voix, dans sa langue, pour créer sa présence
            commerciale et la rendre visible bien au-delà de son cercle.
          </p>
        </div>
        <div className="steps">
          <div className="step reveal">
            <div className="si">i.</div>
            <h3>Parlez</h3>
            <p>
              Vous décrivez votre activité comme vous la raconteriez à un
              client. Pas de champs, pas de menus, juste votre voix.
            </p>
          </div>
          <div className="step reveal">
            <div className="si">ii.</div>
            <h3>Publiez</h3>
            <p>
              Le DJASSAman transforme vos mots en un profil clair : vos offres,
              vos prix, votre contact. Une vraie vitrine, en quelques minutes.
            </p>
          </div>
          <div className="step reveal">
            <div className="si">iii.</div>
            <h3>Vendez</h3>
            <p>
              Vous devenez visible, suivable, joignable. Vos réseaux amplifient
              ; DJASSApp vous donne enfin une base stable.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
