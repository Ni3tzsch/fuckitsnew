import { Waveform } from "../ui/waveform";

export function Demo() {
  return (
    <section className="sec">
      <div className="wrap">
        <div className="sec-head reveal">
          <div className="eyebrow">
            <span className="tick"></span>
            <span className="mono">Ce que fait le DJASSAman</span>
          </div>
          <h2>
            On parle.{" "}
            <span className="em grad-text">La boutique apparaît.</span>
          </h2>
        </div>

        <div className="demo reveal">
          <div className="card voice-card">
            <span className="mono tag">Ce que dit l'entrepreneur</span>
            <p className="voice-line">
              « Je vends attiéké avec poisson à Yopougon. Livraison le midi, je
              prends le mobile money. »
            </p>
            <div className="mini-wave" aria-hidden="true">
              <Waveform
                heights={[14, 22, 12, 26, 16, 24, 10, 20, 14, 22]}
                step={0.08}
              />
            </div>
          </div>
          <div className="arrow">
            <span>➜</span>
          </div>
          <div className="card shop-card">
            <div className="shop-name">Chez Aya — Attiéké</div>
            <div className="shop-cat">Cuisine · Yopougon</div>
            <div className="shop-row">
              <span>Attiéké poisson</span>
              <span>1 500 F</span>
            </div>
            <div className="shop-row">
              <span>Livraison</span>
              <span>Le midi</span>
            </div>
            <div className="shop-row">
              <span>Paiement</span>
              <span>Mobile money</span>
            </div>
            <div className="shop-btn">Contacter la vendeuse</div>
          </div>
        </div>
        <p className="demo-caption reveal">
          Le DJASSAman écoute, structure et publie. Aucun mot à écrire, aucune
          interface à apprendre.
        </p>
      </div>
    </section>
  );
}
