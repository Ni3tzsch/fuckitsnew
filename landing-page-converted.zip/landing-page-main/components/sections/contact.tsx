"use client";

import { useActionState, useState } from "react";
import { sendEmail, ActionState } from "@/app/actions";
import { Waveform } from "../ui/waveform";

const initialState: ActionState = {
  success: false,
  message: "",
};

const ROLES = ["Entrepreneur", "Acheteur", "Investisseur", "Partenaire", "Presse"];

export function Contact() {
  const [state, formAction, isPending] = useActionState(sendEmail, initialState);
  const [selectedRole, setSelectedRole] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const handleRoleClick = (role: string) => {
    setSelectedRole(role);
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    setErrorMsg("");
    const form = e.currentTarget;
    const nameInput = form.querySelector("#name") as HTMLInputElement;
    const emailInput = form.querySelector("#email") as HTMLInputElement;

    if (!nameInput.value.trim()) {
      e.preventDefault();
      nameInput.focus();
      setErrorMsg("Veuillez entrer votre nom.");
      return;
    }

    if (!emailInput.checkValidity()) {
      e.preventDefault();
      emailInput.focus();
      setErrorMsg("Veuillez entrer une adresse email valide.");
      return;
    }
  };

  return (
    <section className="form-sec" id="liste">
      <div className="wrap">
        <div className="form-card reveal">
          <h2>
            Soyez là <span className="em grad-text">au premier mot.</span>
          </h2>
          <p className="sub">
            Entrepreneur, acheteur, investisseur, partenaire ou simplement curieux :
            rejoignez la liste et suivez le lancement.
          </p>

          {state.success ? (
            <div className="success show" role="status">
              <div className="sw" aria-hidden="true">
                <Waveform heights={[10, 16, 8, 18, 12, 14]} step={0.09} />
              </div>
              <h3>C'est noté. À très bientôt.</h3>
              <p>
                Vous serez parmi les premiers prévenus. Au plaisir de bâtir ce projet,
                dès le premier mot.
              </p>
            </div>
          ) : (
            <form action={formAction} onSubmit={handleSubmit} noValidate>
              <div className="field">
                <label htmlFor="name">Nom</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  placeholder="Votre nom"
                  required
                  disabled={isPending}
                />
              </div>
              <div className="field">
                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  placeholder="vous@exemple.com"
                  required
                  disabled={isPending}
                />
              </div>
              <div className="field">
                <label>Vous êtes</label>
                <div className="roles">
                  {ROLES.map((role) => (
                    <button
                      key={role}
                      type="button"
                      className="role"
                      aria-pressed={selectedRole === role}
                      onClick={() => handleRoleClick(role)}
                      disabled={isPending}
                    >
                      {role}
                    </button>
                  ))}
                </div>
                <input type="hidden" name="role" value={selectedRole} />
              </div>

              {errorMsg && (
                <p style={{ color: "#FED6E8", fontSize: "0.85rem", marginTop: "4px" }}>
                  {errorMsg}
                </p>
              )}
              {state.message && !state.success && (
                <p style={{ color: "#FED6E8", fontSize: "0.85rem", marginTop: "4px" }}>
                  {state.message}
                </p>
              )}

              <button type="submit" className="submit" disabled={isPending}>
                {isPending ? "Envoi en cours..." : "Me prévenir au lancement"}
              </button>
              <p className="microcopy">
                Pas de spam. Seulement les grandes étapes du lancement.
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
