import Image from "next/image";

export function OnePhrase() {
  return (
    <section className="one-phrase">
      <div className="wrap one-phrase-grid">
        <div className="one-phrase-copy reveal">
          <div className="eyebrow">
            <span className="tick"></span>
            <span className="mono">En une phrase</span>
          </div>
          <h2 className="one-phrase-title">
            DJASSApp, c'est{" "}
            <span className="em grad-text">le marché, dans votre poche.</span>
          </h2>
          <p className="one-phrase-text">
            Une place de marché en ligne où l'on retrouve les commerçants, les
            produits et les services autour de soi, réunis au même endroit
            plutôt que dispersés sur mille pages. Sa particularité : ici, on
            n'ouvre pas boutique en remplissant des formulaires. On l'ouvre en
            parlant, guidé par le DJASSAman.
          </p>
        </div>
        <div className="one-phrase-media reveal">
          <Image
            src="/djassapp-phones-optimized.png"
            width={1500}
            height={1240}
            sizes="(max-width: 640px) 100vw, (max-width: 980px) 100vw, 55vw"
            loading="lazy"
            alt="Aperçus de l'application DJASSApp sur trois smartphones"
          />
        </div>
      </div>
    </section>
  );
}
