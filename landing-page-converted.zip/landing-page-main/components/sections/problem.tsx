export function Problem() {
  return (
    <section className="sec">
      <div className="wrap">
        <div className="sec-head reveal">
          <div className="eyebrow">
            <span className="tick"></span>
            <span className="mono">Le problème</span>
          </div>
          <h2>
            Le commerce existe déjà.{" "}
            <span className="em grad-text">Il est juste invisible.</span>
          </h2>
          <p>
            En Côte d'Ivoire comme dans une grande partie de l'Afrique, on vend
            déjà en ligne, sur WhatsApp, Facebook et dans les groupes privés.
            Mais cette offre reste prisonnière du réseau personnel, noyée dans
            le flux et presque impossible à retrouver. Il y a les produits, il y
            a la demande ; ce qui manque, c'est le lien entre les deux.
          </p>
        </div>
        <div className="probs reveal">
          <div className="prob">
            <span className="pn">01</span>
            <h3>Prisonnier de son carnet</h3>
            <p>
              Sur WhatsApp, seuls ceux qui ont déjà votre numéro voient vos
              offres. Votre marché s'arrête à vos contacts.
            </p>
          </div>
          <div className="prob">
            <span className="pn">02</span>
            <h3>Noyé dans le flux</h3>
            <p>
              Sur Facebook et Instagram, une offre disparaît en quelques
              heures. La visibilité dépend d'un algorithme, pas du talent.
            </p>
          </div>
          <div className="prob">
            <span className="pn">03</span>
            <h3>Barrière de l'écrit</h3>
            <p>
              Les outils actuels exigent de longs formulaires et une maîtrise
              technique. Ils bloquent de facto l'accès des populations
              non-lettrées ou peu à l'aise avec la tech.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
