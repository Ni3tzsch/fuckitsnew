import Image from "next/image";

export function Impact() {
  return (
    <section className="sec">
      <div className="wrap">
        <div className="impact reveal">
          <div className="eyebrow">
            <span className="tick"></span>
            <span className="mono">Au-delà d'une application</span>
          </div>
          <h2>
            Une porte d'entrée vers l'économie numérique, pour ceux qu'elle
            avait oubliés.
          </h2>
          <div className="impact-body">
            <p>
              Pouvoir vendre ne devrait pas dépendre de savoir lire. Pour des
              millions de personnes, la barrière n'a jamais été le talent, mais
              le clavier. Notre symbole, le Fawohodie, signifie la liberté :
              c'est exactement ce que nous construisons, la liberté
              d'entreprendre, sans condition de diplôme, de réseau ni
              d'alphabétisation.
            </p>
            <div className="impact-logo" aria-hidden="true">
              <Image
                src="/djassapplogo.svg"
                width={116}
                height={110}
                loading="lazy"
                alt=""
              />
            </div>
          </div>
          <p>
            Le point de départ est volontairement concret : partir du terrain,
            des vendeurs, des habitudes de paiement et des langues parlées, pour
            bâtir une infrastructure qui respecte les usages réels.
          </p>
          <div className="langs">
            <div className="lang">
              <div className="lc">Français</div>
              <div className="lt">L'entrepreneuriat à portée de voix.</div>
            </div>
            <div className="lang">
              <div className="lc">English</div>
              <div className="lt">Entrepreneurship, one voice away.</div>
            </div>
            <div className="lang">
              <div className="lc">Español</div>
              <div className="lt">Emprender, al alcance de tu voz.</div>
            </div>
            <div className="lang">
              <div className="lc">Português</div>
              <div className="lt">Empreender ao alcance da sua voz.</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
