export function Ambition() {
  return (
    <section className="sec">
      <div className="wrap">
        <div className="sec-head centered reveal">
          <div className="eyebrow">
            <span className="tick"></span>
            <span className="mono">Ambition continentale &amp; mondiale</span>
          </div>
          <h2>
            Né à Abidjan.{" "}
            <span className="em grad-text">Conçu pour les marchés émergents.</span>
          </h2>
          <p>
            L'exclusion par la complexité numérique touche plus d'un milliard
            d'individus dans le monde. Notre architecture voice-first annule la
            barrière de l'alphabétisation et peut s'adapter aux langues locales.
          </p>
        </div>
        <div className="ambition-grid">
          <div className="ambition-card reveal">
            <span className="ai">01</span>
            <h3>Autonomisation économique</h3>
            <p>
              Donner instantanément aux marchands de rue, aux artisanes et aux
              indépendants les outils des plus grandes enseignes pour élargir
              leur champ d'action commercial.
            </p>
          </div>
          <div className="ambition-card reveal">
            <span className="ai">02</span>
            <h3>Zéro coût d'apprentissage</h3>
            <p>
              Aucune interface complexe à maîtriser. L'application comprend
              l'intention de l'utilisateur à partir de sa simple voix brute.
            </p>
          </div>
          <div className="ambition-card reveal">
            <span className="ai">03</span>
            <h3>Scalabilité linguistique</h3>
            <p>
              Une infrastructure logicielle qui peut s'étendre au-delà
              d'Abidjan : l'expansion ne requiert qu'un entraînement de l'IA
              vocale aux langues locales.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
