export function WhyNow() {
  return (
    <section className="sec">
      <div className="wrap">
        <div className="sec-head reveal">
          <div className="eyebrow">
            <span className="tick"></span>
            <span className="mono">Pourquoi maintenant</span>
          </div>
          <h2>
            Les usages sont déjà là.{" "}
            <span className="em grad-text">L'infrastructure reste à bâtir.</span>
          </h2>
          <p>
            Le smartphone est devenu un outil de vente. Le mobile money a
            installé la transaction numérique dans les habitudes. Les réseaux
            sociaux ont fait naître une génération entière de vendeurs. Tout est
            prêt, mais il manque un système pensé pour rendre cette énergie
            visible, organisée et accessible. C'est exactement le vide que
            DJASSApp vient combler.
          </p>
        </div>
      </div>
    </section>
  );
}
