import Image from "next/image";
import { siteConfig } from "@/config/content";

export function Footer() {
  return (
    <footer>
      <div className="wrap footer-inner">
        <div className="footer-socials" aria-label="Réseaux sociaux">
          <a
            className="social-link"
            href={siteConfig.socials.facebook}
            aria-label="Facebook"
            target="_blank"
            rel="noopener noreferrer"
          >
            <svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor">
              <path d="M14 8.2h2.2V5h-2.8c-3 0-4.6 1.8-4.6 4.8v1.8H6v3.2h2.8V22h3.5v-7.2h3l.5-3.2h-3.5V10c0-1.2.5-1.8 1.7-1.8Z" />
            </svg>
          </a>
          <a
            className="social-link"
            href={siteConfig.socials.linkedin}
            aria-label="LinkedIn"
            target="_blank"
            rel="noopener noreferrer"
          >
            <svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor">
              <path d="M6.8 8.9H3.5V20h3.3V8.9ZM5.2 4C4.1 4 3.3 4.8 3.3 5.8s.8 1.8 1.9 1.8 1.9-.8 1.9-1.8S6.3 4 5.2 4Zm15.5 9.6c0-3-1.6-4.9-4.2-4.9-1.8 0-2.8 1-3.3 1.8V8.9H10V20h3.3v-5.8c0-1.6.8-2.5 2-2.5s2 .8 2 2.6V20h3.3v-6.4Z" />
            </svg>
          </a>
          <a
            className="social-link"
            href={siteConfig.socials.instagram}
            aria-label="Instagram"
            target="_blank"
            rel="noopener noreferrer"
          >
            <svg
              viewBox="0 0 24 24"
              aria-hidden="true"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.9"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="4" y="4" width="16" height="16" rx="4.5" />
              <circle cx="12" cy="12" r="3.5" />
              <path d="M16.7 7.3h.01" />
            </svg>
          </a>
        </div>
        <a href="#top" className="brand">
          <Image
            className="mark"
            src="/djassapplogo.svg"
            width={38}
            height={36}
            alt=""
            aria-hidden="true"
          />
          <span className="name">DJASSApp</span>
        </a>
        <div className="meta">© 2026 DJASSApp. Tous droits réservés.</div>
      </div>
    </footer>
  );
}
