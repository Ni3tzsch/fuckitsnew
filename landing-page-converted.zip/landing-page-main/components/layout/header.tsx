"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { Waveform } from "../ui/waveform";

export function Header() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll(); // Initial check

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <>
      <nav id="nav" className={scrolled ? "scrolled" : ""}>
        <a href="#top" className="brand">
          <Image
            className="mark"
            src="/djassapplogo.svg"
            width={34}
            height={32}
            alt=""
            aria-hidden="true"
          />
          <span className="name">DJASSApp</span>
        </a>
        <div className="nav-right">
          <span className="nav-badge">Pré-lancement · bientôt</span>
          <a href="#fonctionnement" className="btn btn-ghost">
            Fonctionnement
          </a>
          <a href="#investisseurs" className="btn btn-ghost">
            Investisseurs
          </a>
          <a href="#liste" className="btn btn-primary">
            Être prévenu
          </a>
        </div>
      </nav>

      <header id="top">
        <div className="glow a"></div>
        <div className="glow b"></div>
        <div className="wrap hero-inner">
          <div className="eyebrow">
            <span className="tick"></span>
            <span className="mono">Le commerce, par la parole</span>
          </div>
          <h1 className="hero">
            <span className="l">L'entrepreneuriat</span>
            <span className="l">
              à portée de <span className="em grad-text">voix.</span>
            </span>
          </h1>

          <div className="wave" aria-hidden="true">
            <Waveform
              heights={[
                18, 34, 52, 28, 44, 62, 30, 48, 22, 56, 38, 26, 46, 60, 32, 42,
                24, 50, 36, 30, 54, 28, 40, 20,
              ]}
            />
          </div>

          <p className="lede">
            <b>Votre voix. Votre commerce.</b>
            <br />
            Décrivez ce que vous vendez, DJASSApp s'occupe du reste.
          </p>

          <div className="hero-cta">
            <a href="#liste" className="btn btn-primary btn-lg">
              Me prévenir au lancement
            </a>
            <a href="#investisseurs" className="btn btn-ghost btn-lg">
              Espace investisseurs
            </a>
          </div>
        </div>
        <div className="scroll-hint" aria-hidden="true">
          <span>Découvrir</span>
          <span className="bar"></span>
        </div>
      </header>
    </>
  );
}
