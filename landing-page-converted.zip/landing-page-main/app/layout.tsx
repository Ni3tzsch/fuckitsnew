import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "DJASSApp | L'entrepreneuriat à portée de voix",
  description:
    "DJASSApp transforme la voix en commerce. Pré-lancement bientôt. Pour les entrepreneurs délaissés par le digital.",
  keywords: [
    "DJASSApp",
    "marketplace",
    "Afrique de l'Ouest",
    "commerce informel",
    "Côte d'Ivoire",
    "boutique en ligne",
    "commerce vocal",
    "IA vocale",
    "inclusion numérique",
  ],
  authors: [{ name: "DJASSApp" }],
  openGraph: {
    title: "DJASSApp | L'entrepreneuriat à portée de voix",
    description:
      "DJASSApp transforme la voix en commerce. Pré-lancement bientôt. Pour les entrepreneurs délaissés par le digital.",
    type: "website",
    locale: "fr_CI",
    siteName: "DJASSApp",
  },
  twitter: {
    card: "summary_large_image",
    title: "DJASSApp | L'entrepreneuriat à portée de voix",
    description:
      "DJASSApp transforme la voix en commerce. Pré-lancement bientôt. Pour les entrepreneurs délaissés par le digital.",
  },
  icons: {
    icon: "/favicon.svg",
    apple: "/apple-touch-icon.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "DJASSApp",
    url: "https://www.djassapp.com",
    description:
      "DJASSApp transforme la voix en commerce. Pré-lancement bientôt. Pour les entrepreneurs délaissés par le digital.",
    logo: "https://www.djassapp.com/favicon.svg",
    sameAs: [
      "https://www.facebook.com/profile.php?id=61590465520390",
      "https://www.linkedin.com/company/djassapp/",
      "https://www.instagram.com/djassapp/",
    ],
    parentOrganization: {
      "@type": "Organization",
      name: "Ando Technologies",
    },
  };

  return (
    <html lang="fr">
      <body className={`${inter.variable} antialiased`}>
        {children}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </body>
    </html>
  );
}
