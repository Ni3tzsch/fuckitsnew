"use client";

import { useEffect } from "react";
import { Header } from "@/components/layout/header";
import { OnePhrase } from "@/components/sections/one-phrase";
import { Featured } from "@/components/sections/featured";
import { Demo } from "@/components/sections/demo";
import { Problem } from "@/components/sections/problem";
import { Solution } from "@/components/sections/solution";
import { Functioning } from "@/components/sections/functioning";
import { Impact } from "@/components/sections/impact";
import { Ambition } from "@/components/sections/ambition";
import { WhyNow } from "@/components/sections/why-now";
import { Investors } from "@/components/sections/investors";
import { Contact } from "@/components/sections/contact";
import { Footer } from "@/components/layout/footer";

export default function Home() {
  useEffect(() => {
    const revealEls = document.querySelectorAll(".reveal");

    if ("IntersectionObserver" in window) {
      // Reveal on scroll observer
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((e) => {
            if (e.isIntersecting) {
              e.target.classList.add("in");
              io.unobserve(e.target);
            }
          });
        },
        { threshold: 0.12, rootMargin: "0px 0px -6% 0px" }
      );
      revealEls.forEach((el) => io.observe(el));

      // Wave pause when off-screen observer
      const motionIO = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            entry.target.classList.toggle(
              "motion-paused",
              !entry.isIntersecting
            );
          });
        },
        { rootMargin: "80px 0px" }
      );

      document
        .querySelectorAll(".wave, .mini-wave, .success .sw")
        .forEach((el) => motionIO.observe(el));

      return () => {
        io.disconnect();
        motionIO.disconnect();
      };
    } else {
      revealEls.forEach((el) => el.classList.add("in"));
    }
  }, []);

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <OnePhrase />
        <Featured />
        <Demo />
        <Problem />
        <Solution />
        <Functioning />
        <Impact />
        <Ambition />
        <WhyNow />
        <Investors />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
