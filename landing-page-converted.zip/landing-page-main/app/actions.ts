"use server";

import { Resend } from "resend";
import { siteConfig } from "@/config/content";

export type ActionState = {
  success: boolean;
  message: string;
  errors?: {
    [key: string]: string[];
  };
};

export async function sendEmail(
  prevState: ActionState,
  formData: FormData
): Promise<ActionState> {
  const name = formData.get("name") as string;
  const email = formData.get("email") as string;
  const role = formData.get("role") as string;

  // Basic validation
  if (!name || !email) {
    return {
      success: false,
      message: "Veuillez remplir tous les champs obligatoires.",
    };
  }

  // Check for Resend API key
  if (!process.env.RESEND_API_KEY) {
    console.error("Missing RESEND_API_KEY");
    return {
      success: false,
      message:
        "Configuration email manquante. Veuillez configurer RESEND_API_KEY.",
    };
  }

  try {
    const resend = new Resend(process.env.RESEND_API_KEY);
    const { error } = await resend.emails.send({
      from: "DJASSApp <onboarding@resend.dev>",
      to: [siteConfig.contact.email],
      replyTo: email,
      subject: `Nouvelle inscription sur la liste d'attente DJASSApp: ${name}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; color: #333;">
          <h2 style="color: #765979; border-bottom: 2px solid #eee; padding-bottom: 10px;">
            Nouvelle inscription DJASSApp
          </h2>
          <div style="background: #f4eff4; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid rgba(118,89,121,0.13);">
            <p style="margin: 8px 0;"><strong>👤 Nom:</strong> ${name}</p>
            <p style="margin: 8px 0;"><strong>📧 Email:</strong> <a href="mailto:${email}" style="color: #765979;">${email}</a></p>
            <p style="margin: 8px 0;"><strong>🏷️ Rôle:</strong> ${role || "Non renseigné"}</p>
          </div>
          <p style="color: #888; font-size: 12px; margin-top: 20px;">
            Ce message a été envoyé automatiquement depuis la page de pré-lancement DJASSApp.
          </p>
        </div>
      `,
    });

    if (error) {
      console.error("Resend error:", error);
      return {
        success: false,
        message: "Une erreur est survenue lors de l'envoi du message.",
      };
    }

    return { success: true, message: "Inscription réussie !" };
  } catch (error) {
    console.error("Error sending email:", error);
    return {
      success: false,
      message: "Une erreur est survenue lors de l'envoi du message.",
    };
  }
}
